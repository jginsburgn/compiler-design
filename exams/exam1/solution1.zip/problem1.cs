//==========================================================
// Jonathan Ginsburg A01021617
//==========================================================

using System;
using System.IO;
using System.Text.RegularExpressions;

namespace Exam1 {
  public class Problem1 {
    public static void Main(String[] args) {
      System.IO.StreamReader file = new System.IO.StreamReader(args[0]);
      string pattern = @"^(C|c|[*]).*$";
      string line;
      while((line = file.ReadLine()) != null)
      {
        if (!Regex.IsMatch(line, pattern)) {
          Console.WriteLine(line);
        }
      }
    }
  }
}
