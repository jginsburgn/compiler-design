//==========================================================
// Jonathan Ginsburg A01021617
//==========================================================

using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;

namespace Exam1 {
  public class Problem2 {
    public static string Replacer(Match match) {
      return "&#" + Int32.Parse(match.Groups[1].Value, System.Globalization.NumberStyles.HexNumber) + ";";
    }
    public static void Main(String[] args) {
      string source = File.ReadAllText(args[0]);
      Regex regex = new Regex(@"&#x([a-fA-F0-9]*);", RegexOptions.Multiline);
      MatchEvaluator evaluator = new MatchEvaluator(Replacer);
      Console.WriteLine(regex.Replace(source, evaluator));
    }
  }
}
