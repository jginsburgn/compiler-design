//==========================================================
// Type your name and student ID here.
//==========================================================

using System;
using System.IO;
using System.Text.RegularExpressions;

namespace Exam1 {
    public class Problem2 {
        public static void Main(String[] args) {
            // Your code goes here.
        }
    }
}

